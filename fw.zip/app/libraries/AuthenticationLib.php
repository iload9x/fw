<?php 

class AuthenticationLib
{
	
}