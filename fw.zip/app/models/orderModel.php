<?php /**
* 
*/
class orderModel extends InitModel
{	
	protected $table = 'ngoan_cart_orders';
}