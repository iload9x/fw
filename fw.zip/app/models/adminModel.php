<?php 
/**
* 
*/
class adminModel extends InitModel
{
	
	protected $table = 'tamhoa_user';
	protected $fields = array('id','username');
}