<?php 

	class InitController 
	{
		
		function __construct()
		{
			$this->input = new Input();
		}
	}
 ?>